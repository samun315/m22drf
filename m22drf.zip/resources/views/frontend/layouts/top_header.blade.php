<div class="header-top">
    <div class="container">
        <div class="outer-box clearfix">

            <div class="header-top_left pull-left">
                <div class="icon">
                    <img src="assets/frontend/images/icon/arrow-1.png" alt="">
                </div>
                <div class="header-top_left-content">
                    <div class="theme_carousel header-top_left-carousel owl-theme owl-carousel"
                        data-options='{"loop": true, "margin": 0, "autoheight":true, "lazyload":true, "nav": true, "dots": false, "autoplay": true, "autoplayTimeout": 6000, "smartSpeed": 300, "responsive":{ "0" :{ "items": "1" }, "600" :{ "items" : "1" }, "768" :{ "items" : "1" } , "1139":{ "items" : "1" }, "1200":{ "items" : "1" }}}'>
                        <!--Start Single Item-->
                        <div class="single-item">
                            <p>Sponsor an orphan and feed the poor people with us</p>
                        </div>
                        <!--End Single Item-->
                        <!--Start Single Item-->
                        <div class="single-item">
                            <p>Sponsor an orphan and feed the poor people with us</p>
                        </div>
                        <!--End Single Item-->
                    </div>
                </div>
            </div>

            <div class="header-top_right pull-right">
                <div class="header-social-link-1">
                    <ul class="clearfix">
                        <li>
                            <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
    </div>
</div>
